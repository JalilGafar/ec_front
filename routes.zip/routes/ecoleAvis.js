const express = require('express');
const router =express.Router();
var con = require('../db');
var SQL = require('sql-template-strings');

router.get('/', (req, res, next) => {
    con.query(SQL 
        `SELECT id_ecol, sigle_e, nom_e, logo_e, round(AVG(note), 1) AS notes_moy, count(*) AS occurence
        FROM
            (SELECT * 
                FROM 
                    ecoles
                    join
                        avis
                        on (ecoles.id_ecol = avis.id_ecole)
                        )avisEcole
        group by id_ecol, sigle_e, nom_e, logo_e;`, 
        function (err, result, fields) {
        if (err) throw err;
        //console.log(JSON.stringify(result));
        res.status(200).json(result);
        console.log('Les Ecoles ayant des avis !')
    });
    res.status(200);
    //console.log("acces à TopNewsSlides !")
    }
);

module.exports = router;